
`ifndef FILE_INCL
    `include "processor_defines.sv"
`endif

module load(
    input logic i_clk,
    input logic i_rst,
    input logic [31:0] rs1_val,
    input logic [31:0] imm,
    input logic [31:0] mem_data,
    input logic [4:0] rd_in,
    input logic [2:0] load_control,
    output logic stall_pc,
    output logic ignore_curr_inst,
    output logic rd_write_control,
    output logic [4:0] rd_out,
    output logic [31:0] rd_write_val,
    output logic mem_rw_mode,
    output logic [31:0] mem_addr
);

// Edit the code here begin ---------------------------------------------------
logic [2:0] lc;
logic [31:0] ma;
    always @(posedge i_clk or negedge i_rst) begin 
        if (!i_rst) begin
            ignore_curr_inst <= 'b0;
            rd_out <= 5'd0;
            rd_write_control <= 'b0;
            lc <= 3'd0;
            ma <= 32'd0;

        end
        else begin
            if (load_control) begin
                ignore_curr_inst <= 'b1;
                rd_out <= rd_in; 
                rd_write_control <= 'b1;
                lc <= load_control;
                ma <= mem_addr;

            end

            else begin
                ignore_curr_inst <= 'b0;
                rd_out <= 5'd0;
                rd_write_control <= 'b0;
                lc <= 3'd0;
                ma <= 32'd0;
            end
        end
    end

    always @(*) begin
        if (load_control) begin
            stall_pc = 'b1;
            mem_rw_mode = 'b1;
            mem_addr   = rs1_val + imm;
        end
        else begin
            stall_pc = 'b0;
            mem_rw_mode = 'b1;
            mem_addr = 32'd0;
        end

        case (lc)
            3'd0: begin
                rd_write_val=32'd0;
            end

            3'd1: begin
                case (ma[1:0])
                    2'b00: rd_write_val = {{24{mem_data[7]}}, mem_data[7:0]};
                    2'b01: rd_write_val = {{24{mem_data[15]}}, mem_data[15:8]};
                    2'b10: rd_write_val = {{24{mem_data[23]}}, mem_data[23:16]};
                    2'b11: rd_write_val = {{24{mem_data[31]}}, mem_data[31:24]};
                endcase
            end

            3'd2: begin 
                case (ma[1:0]) 
                    2'b00, 2'b01: rd_write_val = {{16{mem_data[15]}}, mem_data[15:0]};
                    2'b10, 2'b11: rd_write_val = {{16{mem_data[31]}}, mem_data[31:16]};
                endcase

            end

            3'd3: begin
                rd_write_val = mem_data;
            end  

            3'd4: begin 
                    case (ma[1:0])
                    2'b00: rd_write_val = {{24'd0}, mem_data[7:0]};
                    2'b01: rd_write_val = {{24'd0}, mem_data[15:8]};
                    2'b10: rd_write_val = {{24'd0}, mem_data[23:16]};
                    2'b11: rd_write_val = {{24'd0}, mem_data[31:24]};
                endcase
            end

            3'd5: begin 
                case (ma[1:0])
                    2'b00, 2'b01: rd_write_val = {{16'd0}, mem_data[15:0]};
                    2'b10, 2'b11: rd_write_val = {{16'd0}, mem_data[31:16]};
                endcase
            
            end             

            default: begin
                stall_pc = 'b0;
                mem_rw_mode = 'b1;
                mem_addr = 32'd0; 
                rd_write_val=32'd0;
            end
        endcase

    end

    
// Edit the code here end -----------------------------------------------------

/*
	Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/load.vcd");
        $dumpvars(0, load);
    end
`endif

endmodule
