
module regfile(
    input logic i_clk,
    input logic i_rst,
    input logic [4:0] rs1,
    input logic [4:0] rs2,
    input logic [4:0] rd,
    input logic rd_write_control,
    input logic [31:0] rd_write_val,
    output logic [31:0] rs1_val,
    output logic [31:0] rs2_val
);

logic [31:0] regs [0:31];

// Edit the code here begin ---------------------------------------------------

assign rs1_val = (rs1 == 5'b0) ? 32'b0 : regs[rs1];
assign rs2_val = (rs2 == 5'b0) ? 32'b0 : regs[rs2];

generate 
    for (genvar ii=0; ii<32; ii +=1) begin : gen_reg_temp
        wire [31:0] reg_dump;
        assign reg_dump = regs[ii];
    end
endgenerate
    
// Edit the code here end -----------------------------------------------------

integer i=0;
always @(posedge i_clk or negedge i_rst) begin 
    if (!i_rst) begin
        for (i=0; i<32; i++) 
            regs[i] <= 32'b0;
    end
    else begin
        regs[0] <= 32'b0;
        if (rd_write_control) regs[rd] <= rd_write_val;
    end
end 

/*
    Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/regfile.vcd");
        $dumpvars(0, regfile);
    end
`endif

endmodule
