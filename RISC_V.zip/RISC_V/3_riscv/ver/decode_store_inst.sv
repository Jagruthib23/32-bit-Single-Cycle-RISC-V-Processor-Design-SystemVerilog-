
`ifndef FILE_INCL
    `include "processor_defines.sv"
`endif

module decode_store_inst(
    input logic [31:7] instruction_code,
    output logic [4:0] rs1,
    output logic [4:0] rs2,
    output logic [11:0] imm,
    output logic [2:0] store_control
);

// Edit the code here begin ---------------------------------------------------

    logic [2:0] funct3;
    assign rs1 = instruction_code[19:15];
    assign rs2 = instruction_code[24:20];
    assign imm[4:0] = instruction_code[11:7];
    assign imm[11:5] = instruction_code[31:25];
    assign funct3 = instruction_code[14:12];
    
// Edit the code here end -----------------------------------------------------
    always @(*) begin
        case (funct3)
            3'b000: store_control = `SB;
            3'b001: store_control = `SH;
            3'b010: store_control = `SW;
            default: store_control = `STR_NOP;   
        endcase
    end

/*
	Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/decode_store_inst.vcd");
        $dumpvars(0, decode_store_inst);
    end
`endif

endmodule
