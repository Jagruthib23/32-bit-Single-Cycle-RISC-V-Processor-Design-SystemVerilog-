
`ifndef FILE_INCL
    `include "processor_defines.sv"
`endif

module store(
    input logic i_clk,
    input logic i_rst,
    input logic [31:0] rs1_val,
    input logic [31:0] rs2_val,
    input logic [31:0] imm,
    input logic [2:0] store_control,
    output logic stall_pc,
    output logic ignore_curr_inst,
    output logic mem_rw_mode,
    output logic [31:0] mem_addr,
    output logic [31:0] mem_write_data,
    output logic [3:0] mem_byte_en
);

// Edit the code here begin ---------------------------------------------------

    always @(posedge i_clk or negedge i_rst) begin 
        if (!i_rst) ignore_curr_inst <= 'b0;
        else begin
            if (store_control) ignore_curr_inst <= 'b1;
            else ignore_curr_inst <= 'b0;
        end
    end

    always @(*) begin
        case (store_control)
            3'd0: begin
                stall_pc = 'd0;
                mem_addr = 32'd0;
                mem_write_data = 32'd0;
                mem_byte_en = 4'd0;
                mem_rw_mode = 'b1;
            end 

            3'd1: begin
                stall_pc    = 1'b1;
                mem_addr    = rs1_val + imm;
                mem_rw_mode = 1'b0;

                case (mem_addr[1:0])
                    2'b00: begin
                        mem_write_data = {24'd0, rs2_val[7:0]};
                        mem_byte_en    = 4'b0001;
                    end

                    2'b01: begin
                        mem_write_data = {16'd0, rs2_val[7:0], 8'd0};
                        mem_byte_en    = 4'b0010;
                    end

                    2'b10: begin
                        mem_write_data = {8'd0, rs2_val[7:0], 16'd0};
                        mem_byte_en    = 4'b0100;
                    end

                    2'b11: begin
                        mem_write_data = {rs2_val[7:0], 24'd0};
                        mem_byte_en    = 4'b1000;
                    end
                endcase
            end

            3'd2: begin
                stall_pc    = 1'b1;
                mem_addr    = rs1_val + imm;
                mem_rw_mode = 1'b0;

                case (mem_addr[1:0])
                    2'b00, 2'b01: begin
                        mem_write_data = {16'd0, rs2_val[15:0]};
                        mem_byte_en    = 4'b0011;
                    end

                    2'b10, 2'b11: begin
                        mem_write_data = {rs2_val[15:0], 16'd0};
                        mem_byte_en    = 4'b1100;
                    end
                endcase
            end

            3'd3: begin
                stall_pc = 'd1;
                mem_addr = rs1_val + imm;
                mem_write_data = rs2_val;
                mem_byte_en = 4'b1111;
                mem_rw_mode = 'b0;
            end 

            default: begin
                stall_pc = 'd0;
                mem_addr = 32'd0;
                mem_write_data = 32'd0;
                mem_byte_en = 4'd0;
                mem_rw_mode = 'b1;
            end 
        endcase
    end
    
// Edit the code here end -----------------------------------------------------

/*
	Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/store.vcd");
        $dumpvars(0, store);
    end
`endif

endmodule
