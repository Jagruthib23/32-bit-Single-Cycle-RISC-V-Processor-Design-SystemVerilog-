
`ifndef FILE_INCL
    `include "processor_defines.sv"
`endif

module branch(
    input logic i_clk,
    input logic i_rst,
    input logic [31:0] pc_prev,
    input logic [31:0] imm,
    input logic [31:0] rs1_val,
    input logic [31:0] rs2_val,
    input logic [2:0] branch_control,
    output logic pc_update_control,
    output logic [31:0] pc_update_val,
    output logic ignore_curr_inst
);

// Edit the code here begin ---------------------------------------------------

    always @(posedge i_clk or negedge i_rst) begin
        if (!i_rst) ignore_curr_inst <= 1'b0;
        else begin
            case (branch_control)
            3'b0: ignore_curr_inst<=1'b0;
            3'b1: begin 
                if (rs1_val == rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end

            3'd2: begin 
                if (rs1_val != rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end

            3'd3: begin 
                if (rs1_val < rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end

            3'd4: begin 
                if (rs1_val >= rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end

            3'd5: begin 
                if (rs1_val < rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end

            3'd6: begin 
                if (rs1_val >= rs2_val) ignore_curr_inst<=1'b1;
                else ignore_curr_inst<=1'b0;
            end       

            default: begin 
                ignore_curr_inst<=1'b0;
            end           

            endcase
        end
    end

    always @(*) begin
        case (branch_control)
            3'd1: begin 
                if (rs1_val == rs2_val) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
                else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end
            end

            3'd2: begin 
                if (rs1_val != rs2_val) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
               else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end             
            end

            3'd3: begin 
                if ($signed(rs1_val) < $signed(rs2_val)) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
               else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end              
            end

            3'd4: begin 
                if ($signed(rs1_val) >= $signed(rs2_val)) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
               else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end               
            end

            3'd5: begin
                if (rs1_val < rs2_val) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
               else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end           
            end

            3'd6: begin 
                if (rs1_val >= rs2_val) begin
                pc_update_control = 1'b1;
                pc_update_val = pc_prev + imm;
                end
               else begin
                pc_update_val = 32'd0;
                pc_update_control = 32'd0;
                end              
            end

            3'd0: begin 
                pc_update_control = 1'b0;
                pc_update_val = 32'd0;
            end           

            default: begin
                pc_update_control = 1'b0;
                pc_update_val = 32'd0;
            end
        endcase
    end
    
// Edit the code here end -----------------------------------------------------

/*
	Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/branch.vcd");
        $dumpvars(0, branch);
    end
`endif

endmodule
