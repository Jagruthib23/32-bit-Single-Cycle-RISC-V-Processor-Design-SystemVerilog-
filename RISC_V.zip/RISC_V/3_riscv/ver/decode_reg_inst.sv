`ifndef FILE_INCL
    `include "processor_defines.sv"
`endif

module decode_reg_inst(
    input logic [31:7] instruction_code,
    output logic [4:0] rs1,
    output logic [4:0] rs2,
    output logic [4:0] rd,
    output logic [4:0] alu_control
);

// Edit the code here begin ---------------------------------------------------
    logic [2:0] funct3;
    logic [6:0] funct7;
    assign rs1 = instruction_code[19:15];
    assign rs2 = instruction_code[24:20];
    assign rd = instruction_code[11:7];
    assign funct3 = instruction_code[14:12];
    assign funct7 = instruction_code[31:25];

    always @(*) begin
        case ({funct3,funct7})
            10'b0000000000: alu_control = `ADD;
            10'b0000100000: alu_control = `SUB;
            10'b1000000000: alu_control = `XOR;
            10'b1100000000: alu_control = `OR;
            10'b1110000000: alu_control = `AND;
            10'b0010000000: alu_control = `SLL;
            10'b1010000000: alu_control = `SRL;
            10'b1010100000: alu_control = `SRA;
            10'b0100000000: alu_control = `SLT;
            10'b0110000000: alu_control = `SLTU;
            default: alu_control = `ALU_NOP;
        endcase
    end
    
// Edit the code here end -----------------------------------------------------

/*
	Following section is necessary for dumping waveforms. This is needed for debug and simulations
*/

`ifndef SUBMODULE_DISABLE_WAVES
    initial begin
        $dumpfile("./sim_build/decode_reg_inst.vcd");
        $dumpvars(0, decode_reg_inst);
    end
`endif

endmodule
